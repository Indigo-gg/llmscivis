<script setup>
// import HelloWorld from './components/HelloWorld.vue'
import Demo from './components/demo.vue'
</script>

<template>
<router-view></router-view>
</template>

<style>
html,body{
  margin: 0;
  padding: 0;
}
.v-list-item__content{
  width: 100%;
}

</style>
